from setuptools import find_packages, setup

package_name = 'nav_int_integration'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    py_modules=['unt'],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='yogesh',
    maintainer_email='yogesh@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'start_node = nav_int_integration.unt:main',
        ],
    },
)
