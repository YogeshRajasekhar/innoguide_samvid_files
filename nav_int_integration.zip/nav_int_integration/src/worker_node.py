#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import json
from example_interfaces.srv import TalkRequest  # Use your package name

class WorkerNode(Node):
    def __init__(self):
        super().__init__('worker_node')
        self.srv = self.create_service(TalkRequest, 'start_speaking', self.handle_request)

    def handle_request(self, request, response):
        self.get_logger().info(f"Received JSON request: {request.request_json}")
        
        # Parse the JSON
        try:
            data = json.loads(request.request_json)
            message = data.get("message", "Default message")
            self.get_logger().info(f"Speaking: {message}")
            
            # Simulate speaking (replace with actual functionality if needed)
            self.get_logger().info("Speaking...")
            
            # Create a JSON response
            response_data = {"status": "done", "details": f"Spoke message: {message}"}
            response.response_json = json.dumps(response_data)
        except json.JSONDecodeError:
            self.get_logger().error("Invalid JSON")
            response.response_json = json.dumps({"status": "error", "details": "Invalid JSON"})

        return response

def main(args=None):
    rclpy.init(args=args)
    worker_node = WorkerNode()
    rclpy.spin(worker_node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
