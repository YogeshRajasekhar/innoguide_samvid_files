#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import subprocess


class StarterNode(Node):
    def __init__(self):
        super().__init__('starter_node')
        self.get_logger().info("StarterNode is running. Waiting to start another node...")

    def start_another_node(self, node_name, package_name):
        """Starts another ROS2 node."""
        try:
            #self.get_logger().info(f"Starting node '{node_name}' from package '{package_name}'...")
            subprocess.Popen(['ros2', 'launch', package_name, node_name])
            #self.get_logger().info(f"Node '{node_name}' started successfully!")
        except Exception as e:
            self.get_logger().error(f"Failed to start node '{node_name}': {e}")


def main(args=None):
    rclpy.init(args=args)
    node = StarterNode()
    
    # Example usage: Start a node called `example_node` from the package `example_package`
    node.start_another_node('turtlebot3_gazebo', 'turtlebot3_world.launch.py')

    # Spin the node to keep it running
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
