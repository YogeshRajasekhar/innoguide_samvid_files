#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import json
from nav_int_integration.srv import TalkRequest

class RequesterNode(Node):
    def __init__(self):
        super().__init__('requester_node')
        self.client = self.create_client(TalkRequest, 'start_speaking')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for the service to be available...')
        self.send_request()

    def send_request(self):
        # Create a JSON request
        request_json = json.dumps({"message": "Hello, I am speaking!"})
        request = TalkRequest.Request()
        request.request_json = request_json
        
        self.future = self.client.call_async(request)
        self.future.add_done_callback(self.handle_response)

    def handle_response(self, future):
        try:
            response = future.result()
            self.get_logger().info(f"Received JSON response: {response.response_json}")

            # Parse the response and stop another node if needed
            response_data = json.loads(response.response_json)
            if response_data.get("status") == "done":
                self.get_logger().info("Request completed successfully. Sending stop signal...")
                # Logic to stop another node (implement as needed)
        except Exception as e:
            self.get_logger().error(f"Service call failed: {e}")

def main(args=None):
    rclpy.init(args=args)
    requester_node = RequesterNode()
    rclpy.spin(requester_node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
