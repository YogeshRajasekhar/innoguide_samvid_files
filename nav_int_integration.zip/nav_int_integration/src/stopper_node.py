#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

class StopperNode(Node):
    def __init__(self):
        super().__init__('stopper_node')
        self.get_logger().info("Stopper Node started. Waiting for stop signal...")

    def stop(self):
        self.get_logger().info("Stopping operation...")

def main(args=None):
    rclpy.init(args=args)
    stopper_node = StopperNode()
    stopper_node.stop()  # Trigger stop manually for now
    rclpy.shutdown()

if __name__ == '__main__':
    main()
