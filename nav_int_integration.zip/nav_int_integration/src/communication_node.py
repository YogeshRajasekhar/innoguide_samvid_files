#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String  # Example message type

class MyNode(Node):
    def __init__(self):
        super().__init__('nav_int')  # Node name
        #self.get_logger().info("Node has been started")

        # Create a publisher
        self.publisher_ = self.create_publisher(String, 'topic_name', 10)

        # Create a subscriber
        self.subscriber_ = self.create_subscription(
            String,
            'topic_name',
            self.callback_function,
            10
        )

        # Create a timer
        self.timer_ = self.create_timer(1.0, self.timer_callback)

    def callback_function(self, msg):
        self.get_logger().info(f'Received: "{msg.data}"')

    def timer_callback(self):
        msg = String()
        msg.data = 'Hello, ROS 2!'
        self.publisher_.publish(msg)
        self.get_logger().info(f'Published: "{msg.data}"')

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node stopped cleanly')
    except Exception as e:
        node.get_logger().error(f'Error: {str(e)}')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
