from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[
                {
                    'use_sim_time': False,  # Correct Python syntax for a dictionary key-value pair
                    'slam_mode': "mapping",  # String values must be quoted
                    'resolution': 0.05,
                    'max_laser_range': 15.0,
                    'minimum_time_interval': 2.0,
                    'map_update_interval': 2.0,
                    'scan_topic': "/scan",
                    'minimum_travel_distance': 0.2,
                    'minimum_travel_heading': 0.174,
                    'maximum_heading_variance': 0.17,
                    'map_frame': "map",
                    'odom_frame': "odom",
                    'base_frame': "base_link",
                    'publish_frame_projected_to_2d': True  # Capitalized Python boolean
                }
            ],
            remappings=[
                ('scan', '/scan'),  # Remap the 'scan' topic
            ],
        ),
    ])
