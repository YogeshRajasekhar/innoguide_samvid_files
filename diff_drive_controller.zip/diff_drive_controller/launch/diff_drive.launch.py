from launch import LaunchDescription
from launch_ros.actions import Node
import os
from launch import LaunchDescription
#from launch.actions import DeclareLaunchArgument, LogInfo, PushRosNamespace, DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, ThisLaunchFileDir
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package="controller_manager",
            executable="ros2_control_node",
            parameters=[os.path.join( ThisLaunchFileDir(), '..', 'config', 'diff_drive.yaml')],
            output="screen"
        )
    ])

